public class chartest {

    public static void main(String[] args) {
        char ch1, ch2;
        ch1 = 'A';
        ch2 = 75;
        System.out.println("ch1 is: " + ch1);
        ch1++;
        System.out.println("ch1 is now: " + ch1);
        System.out.println("ch2 is :" + ch2);
        System.out.println("ch1 + ch2 =" + (ch1 + ch2));
    }
}
