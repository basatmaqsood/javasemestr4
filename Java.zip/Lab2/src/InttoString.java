public class InttoString {
    public static void main(String[] args) {
// create int type variable
        int num = 10;
        System.out.println("The integer value is: " + num);
// converts int to string type
 String data = String.valueOf(num);
        System.out.println("The string value is: " + data);
    }
}

