public class widening {

        public static void main(String[] args) {
// create int type variable
            int num = 10;
            System.out.println("The integer value: " + num);
// convert into double type
            double data = num;
            System.out.println("The double value: " + data);}}


