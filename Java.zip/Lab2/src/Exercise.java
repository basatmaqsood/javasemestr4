public class Exercise
{
    public static void main(String[] args){
        System.out.println((int)'A');
        System.out.println((int)'B');
        System.out.println((int)'C');
        System.out.println((int)'a');
        System.out.println((int)'b');
        System.out.println((int)'c');
    }
}
