public class Variables {


    public static void main(String[] args) {

        int a = 1; //static variable int data = 99;
        int b = 90; //local variable
        System.out.println("value of local variable b is : " + b);
    }
}
