public class Dynamic {

        public static void main(String[] args) { int sum = Math.addExact(10, 20); System.out.println("Sum : " + sum);
            int sub = Math.subtractExact(20, 10); System.out.println("Substract : " + sub);
        }
    }
