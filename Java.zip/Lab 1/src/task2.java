class task2
{
    public static void main(String args[])
    {
        System.out.println("hello world!");
    }
}
class task2_1
{
    public static void main(String args[])
    {
        System.out.println("This is my First Program!");
    }
}
