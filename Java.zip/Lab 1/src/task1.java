class task1 {
    public static void main(String[] args) {
        int a,b,c; //this statement declares three variables a, b and c.
        a=2;
        b=3;
        c=a+b;
        System.out.println("Sum of two numbers = "+c);
    }
}

